<?php
$gpa_value="";
$gpa_status="";


if (isset($_POST['submit'])) {
	$subone_first=$_POST['subone_first'];
	$subtwo_first=$_POST['subtwo_first'];

	$subone_second=$_POST['subone_second'];
	$subtwo_second=$_POST['subtwo_second'];

	function getvalue($value)
	{

		if ($value=="A") {
		$val=5;

	}elseif ($value=="B") {
		$val=4;
	}

	elseif ($value=="C") {
		$val=3;
	}
	elseif ($value=="D") {
		$val=2;
	}

	elseif($value=="E") {
		$val=1;

	}


	
	return $val;



	}
	
   $valueone_first_sem=getvalue($subone_first);
  $valueone_second_sem=getvalue($subone_second);

  $valuetwo_first_sem=getvalue($subtwo_first);
   $valuetwo_second_sem=getvalue($subtwo_second);

   //$gpa_value_one=($valueone_first_sem *9)/21;
   //$gpa_value_two=($valuetwo_first_sem *12)/21;

   $gpa_value_one=($valueone_first_sem *9)/21;
   $gpa_value_two=($valuetwo_first_sem *12)/21;

   $gpa_value_one2=($valueone_second_sem *9)/21;
   $gpa_value_two2=($valuetwo_second_sem *12)/21;

   $gpa_value=($gpa_value_one2+$gpa_value_two2+$gpa_value_one+$gpa_value_two)/2;


   if ($gpa_value > "2.5") {
   	$gpa_status="pass";
   	# code...
   }else{
	$gpa_status="fail";

   }


	//$subone_second=$_POST['subone_second'];
	//$subtwo_second=$_POST['subtwo_second'];


	# code...
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>GPA CALCULATOR</title>
</head>
<body align="center">
	<form method="POST" action="interview_test.php">
<br><br>
<table border="2" align="center">
	<tr>
		<td>SUBJECT</td>
		<td>FIRST SEMESTER</td>
		<td>SECOND SEMESTER</td>
		<td>POINT</td>
	</tr>
	<tbody>
		<tr>
		<td>Subject one </td>
		<td><input type="text" name="subone_first"> </td>
		<td> <input type="text" name="subone_second"></td>
		<td>9</td>
	</tr>

	<tr>
		<td>Subject two </td>
		<td><input type="text" name="subtwo_first"> </td>
		<td> <input type="text" name="subtwo_second"></td>
		<td>12</td>
	</tr>
			
		
		
	</tbody>
	
		</table>
	<br>
	<input type="submit" name="submit" value="CALCULATE GPA"><br><br>
	GPA is<b><?php echo $gpa_value; ?></b>
	<br>STATUS  &nbsp;<b><?php echo $gpa_status; ?></b>
	
</form>
</body>
<br>
</body>
</html>